# Literature Review

> **Soohwan Lee**
Master Student
EXPC Lab, Grad. School of Creative Design Engineering
E-mail: soohwanlee@unist.ac.kr, shlee.shawn@gmail.com

[Interaction Design](Literature%20Review%2060a34216d33b440e8b863ca0d1e92329/Interaction%20Design%2056c675313b3e45d091488d5045667a3a.csv)